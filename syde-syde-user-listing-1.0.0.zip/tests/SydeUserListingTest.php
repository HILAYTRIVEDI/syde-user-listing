<?php

declare(strict_types=1);

namespace Syde\UserListing\Tests;

use PHPUnit\Framework\TestCase;

class SydeUserListingTest extends TestCase
{
    public function setup(): void
    {
        parent::setup();
    }

    public function tearDown(): void
    {
        parent::tearDown();
    }
}
